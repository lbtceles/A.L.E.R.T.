﻿namespace A.L.E.R.T_Client
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.botPanel = new System.Windows.Forms.Panel();
            this.botLabel = new System.Windows.Forms.Label();
            this.topPanel = new System.Windows.Forms.Panel();
            this.topLabel = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.gmap = new GMap.NET.WindowsForms.GMapControl();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnResolve = new System.Windows.Forms.Button();
            this.btnCallForHelp = new System.Windows.Forms.Button();
            this.botPanel.SuspendLayout();
            this.topPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // botPanel
            // 
            this.botPanel.BackColor = System.Drawing.Color.PaleGreen;
            this.botPanel.Controls.Add(this.botLabel);
            this.botPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.botPanel.Location = new System.Drawing.Point(0, 526);
            this.botPanel.Name = "botPanel";
            this.botPanel.Size = new System.Drawing.Size(1087, 36);
            this.botPanel.TabIndex = 6;
            // 
            // botLabel
            // 
            this.botLabel.AutoSize = true;
            this.botLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botLabel.Location = new System.Drawing.Point(8, 8);
            this.botLabel.Name = "botLabel";
            this.botLabel.Size = new System.Drawing.Size(69, 18);
            this.botLabel.TabIndex = 4;
            this.botLabel.Text = "Status: ";
            // 
            // topPanel
            // 
            this.topPanel.BackColor = System.Drawing.Color.PaleGreen;
            this.topPanel.Controls.Add(this.topLabel);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPanel.Location = new System.Drawing.Point(0, 0);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(1087, 36);
            this.topPanel.TabIndex = 5;
            // 
            // topLabel
            // 
            this.topLabel.AutoSize = true;
            this.topLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topLabel.Location = new System.Drawing.Point(8, 6);
            this.topLabel.Name = "topLabel";
            this.topLabel.Size = new System.Drawing.Size(115, 24);
            this.topLabel.TabIndex = 3;
            this.topLabel.Text = "A.L.E.R.T.";
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(73, 493);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.Size = new System.Drawing.Size(64, 27);
            this.dgv.TabIndex = 5;
            // 
            // gmap
            // 
            this.gmap.Bearing = 0F;
            this.gmap.CanDragMap = true;
            this.gmap.EmptyTileColor = System.Drawing.Color.Navy;
            this.gmap.GrayScaleMode = false;
            this.gmap.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
            this.gmap.LevelsKeepInMemmory = 5;
            this.gmap.Location = new System.Drawing.Point(0, 32);
            this.gmap.MarkersEnabled = true;
            this.gmap.MaxZoom = 2;
            this.gmap.MinZoom = 2;
            this.gmap.MouseWheelZoomEnabled = true;
            this.gmap.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gmap.Name = "gmap";
            this.gmap.NegativeMode = false;
            this.gmap.PolygonsEnabled = true;
            this.gmap.RetryLoadTile = 0;
            this.gmap.RoutesEnabled = true;
            this.gmap.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
            this.gmap.SelectedAreaFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.gmap.ShowTileGridLines = false;
            this.gmap.Size = new System.Drawing.Size(1087, 498);
            this.gmap.TabIndex = 7;
            this.gmap.Zoom = 0D;
            this.gmap.Click += new System.EventHandler(this.gmap_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.btnCallForHelp);
            this.panel1.Controls.Add(this.btnResolve);
            this.panel1.Location = new System.Drawing.Point(27, 103);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(205, 357);
            this.panel1.TabIndex = 8;
            this.panel1.Visible = false;
            // 
            // btnResolve
            // 
            this.btnResolve.Location = new System.Drawing.Point(34, 100);
            this.btnResolve.Name = "btnResolve";
            this.btnResolve.Size = new System.Drawing.Size(135, 39);
            this.btnResolve.TabIndex = 5;
            this.btnResolve.Text = "Resolve";
            this.btnResolve.UseVisualStyleBackColor = true;
            this.btnResolve.Click += new System.EventHandler(this.btnResolve_Click);
            // 
            // btnCallForHelp
            // 
            this.btnCallForHelp.Location = new System.Drawing.Point(35, 194);
            this.btnCallForHelp.Name = "btnCallForHelp";
            this.btnCallForHelp.Size = new System.Drawing.Size(135, 39);
            this.btnCallForHelp.TabIndex = 6;
            this.btnCallForHelp.Text = "Call For Help";
            this.btnCallForHelp.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1087, 562);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.gmap);
            this.Controls.Add(this.botPanel);
            this.Controls.Add(this.topPanel);
            this.Controls.Add(this.dgv);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.botPanel.ResumeLayout(false);
            this.botPanel.PerformLayout();
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel botPanel;
        private System.Windows.Forms.Label botLabel;
        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Label topLabel;
        private System.Windows.Forms.DataGridView dgv;
        private GMap.NET.WindowsForms.GMapControl gmap;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnCallForHelp;
        private System.Windows.Forms.Button btnResolve;
    }
}

