﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GMap.NET.WindowsForms;
using GMap.NET.MapProviders;
using GMap.NET;
using GMap.NET.WindowsForms.Markers;
using System.Data.SqlClient;


namespace A.L.E.R.T_Client
{
    public partial class Form1 : Form
    {
        double lati;
        double longti;

        GMapOverlay overLay = new GMapOverlay();

        SqlConnection con = new SqlConnection(@"Data Source = tcp:LANCE-PC,49162;Initial Catalog = A.L.E.R.T; User ID = sa;Password = zerothreesix");

        //SqlConnection con = new SqlConnection(@"Data Source=.\SQLExpress;Initial Catalog=A.L.E.R.T;Integrated Security=True");
        SqlDataAdapter sda;
        SqlCommand cmd;

        DataTable dt = new DataTable();
        GMapMarker mapMarker;

        int index;
        int markerIndex;

        public Form1()
        {
            InitializeComponent();

            gmap.MapProvider = GMapProviders.GoogleMap; //setting of map provider
            gmap.Position = new PointLatLng(14.5823, 121.1260);

            gmap.MinZoom = 1;
            gmap.MaxZoom = 100;
            gmap.Zoom = 15;

            gmap.DragButton = MouseButtons.Left;
            gmap.AutoScroll = true;
            gmap.ShowCenter = false;

            gmap.Overlays.Add(overLay);
        }

        public void refreshGMap()
        {
            gmap.Overlays.Add(overLay);

            double poslat = 14.5823;
            double poslong = 121.1260;
            PointLatLng pospoint = new PointLatLng(poslat, poslong);
            mapMarker = new GMarkerGoogle(pospoint, GMarkerGoogleType.blue_dot);
            mapMarker.ToolTipText = "Your Location";
            overLay.Markers.Add(mapMarker);

            try
            {
                sda = new SqlDataAdapter("SELECT * FROM tblMarkers WHERE Team = 'Alpha' AND Status = 'Active'", con);
                sda.Fill(dt);
                dgv.DataSource = dt;

                DataGridViewRow row = dgv.Rows[0];
                lati = Convert.ToDouble(row.Cells[1].Value);
                longti = Convert.ToDouble(row.Cells[2].Value);

                PointLatLng point = new PointLatLng(lati, longti);

                if (row.Cells[3].Value.ToString() == "Fire")
                    mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.red_dot);
                else if (row.Cells[3].Value.ToString() == "Road Accidents")
                    mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.orange_dot);
                else
                    mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.green_dot);

                mapMarker.ToolTipText = row.Cells[0].Value.ToString() + " - " + row.Cells[3].Value.ToString();
                overLay.Markers.Add(mapMarker);
            }
            catch(Exception ex)
            {

            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            double poslat = 14.5823;
            double poslong = 121.1260;
            PointLatLng pospoint = new PointLatLng(poslat, poslong);
            mapMarker = new GMarkerGoogle(pospoint, GMarkerGoogleType.blue_dot);
            mapMarker.ToolTipText = "Your Location";
            overLay.Markers.Add(mapMarker);

            //CHECKING IF THE DATABASE CAN BE ACCESSED
            try
            {
                con.Open();
                botLabel.Text = botLabel.Text + " Connected!";
                con.Close();
            }
            catch (Exception ex)
            {
                botLabel.Text = botLabel.Text + " Not Connected!";
            }

            try
            {
                //LOADING THE MARKERS
                sda = new SqlDataAdapter("SELECT * FROM tblMarkers WHERE Team = 'Alpha' AND Status = 'Active'", con);
                sda.Fill(dt);
                dgv.DataSource = dt;

                DataGridViewRow row = dgv.Rows[0];
                lati = Convert.ToDouble(row.Cells[1].Value);
                longti = Convert.ToDouble(row.Cells[2].Value);

                PointLatLng point = new PointLatLng(lati, longti);

                if (row.Cells[3].Value.ToString() == "Fire")
                    mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.red_dot);
                else if (row.Cells[3].Value.ToString() == "Road Accidents")
                    mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.orange_dot);
                else
                    mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.green_dot);

                mapMarker.ToolTipText = row.Cells[0].Value.ToString() + " - " + row.Cells[3].Value.ToString();
                overLay.Markers.Add(mapMarker);

            }
            catch(Exception ex)
            {

            }



            gmap.OnMarkerClick += (marker, mouseArgs) =>
            {
                if(marker.ToolTipText != "Your Location")
                {
                    panel1.Visible = true;
                    markerIndex = marker.ToolTipText[0];
                }
            };
        }

        private void gmap_Click(object sender, EventArgs e)
        {
            panel1.Visible = false;
        }

        private void btnResolve_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("UPDATE tblMarkers Set Status = 'Resolved' WHERE Team = 'Alpha'",con);
            cmd.ExecuteNonQuery();
            con.Close();

            overLay.Markers.RemoveAt(1);

        }
    }
}
