﻿namespace A.L.E.R.T_Server
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gmap = new GMap.NET.WindowsForms.GMapControl();
            this.topPanel = new System.Windows.Forms.Panel();
            this.topLabel = new System.Windows.Forms.Label();
            this.botPanel = new System.Windows.Forms.Panel();
            this.botLabel = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.tbLat = new System.Windows.Forms.TextBox();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbTeam = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbEmergency = new System.Windows.Forms.ComboBox();
            this.lbEmergency = new System.Windows.Forms.Label();
            this.tbLong = new System.Windows.Forms.TextBox();
            this.lbLong = new System.Windows.Forms.Label();
            this.lbLat = new System.Windows.Forms.Label();
            this.topPanel.SuspendLayout();
            this.botPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gmap
            // 
            this.gmap.Bearing = 0F;
            this.gmap.CanDragMap = true;
            this.gmap.EmptyTileColor = System.Drawing.Color.Navy;
            this.gmap.GrayScaleMode = false;
            this.gmap.HelperLineOption = GMap.NET.WindowsForms.HelperLineOptions.DontShow;
            this.gmap.LevelsKeepInMemmory = 5;
            this.gmap.Location = new System.Drawing.Point(0, 33);
            this.gmap.MarkersEnabled = true;
            this.gmap.MaxZoom = 2;
            this.gmap.MinZoom = 2;
            this.gmap.MouseWheelZoomEnabled = true;
            this.gmap.MouseWheelZoomType = GMap.NET.MouseWheelZoomType.MousePositionAndCenter;
            this.gmap.Name = "gmap";
            this.gmap.NegativeMode = false;
            this.gmap.PolygonsEnabled = true;
            this.gmap.RetryLoadTile = 0;
            this.gmap.RoutesEnabled = true;
            this.gmap.ScaleMode = GMap.NET.WindowsForms.ScaleModes.Integer;
            this.gmap.SelectedAreaFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(65)))), ((int)(((byte)(105)))), ((int)(((byte)(225)))));
            this.gmap.ShowTileGridLines = false;
            this.gmap.Size = new System.Drawing.Size(1103, 538);
            this.gmap.TabIndex = 0;
            this.gmap.Zoom = 0D;
            this.gmap.MouseClick += new System.Windows.Forms.MouseEventHandler(this.gmap_MouseClick);
            this.gmap.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.gmap_DoubleClick);
            // 
            // topPanel
            // 
            this.topPanel.BackColor = System.Drawing.Color.PaleGreen;
            this.topPanel.Controls.Add(this.topLabel);
            this.topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.topPanel.Location = new System.Drawing.Point(0, 0);
            this.topPanel.Name = "topPanel";
            this.topPanel.Size = new System.Drawing.Size(1103, 36);
            this.topPanel.TabIndex = 1;
            // 
            // topLabel
            // 
            this.topLabel.AutoSize = true;
            this.topLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.topLabel.Location = new System.Drawing.Point(8, 6);
            this.topLabel.Name = "topLabel";
            this.topLabel.Size = new System.Drawing.Size(115, 24);
            this.topLabel.TabIndex = 3;
            this.topLabel.Text = "A.L.E.R.T.";
            // 
            // botPanel
            // 
            this.botPanel.BackColor = System.Drawing.Color.PaleGreen;
            this.botPanel.Controls.Add(this.botLabel);
            this.botPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.botPanel.Location = new System.Drawing.Point(0, 565);
            this.botPanel.Name = "botPanel";
            this.botPanel.Size = new System.Drawing.Size(1103, 36);
            this.botPanel.TabIndex = 2;
            // 
            // botLabel
            // 
            this.botLabel.AutoSize = true;
            this.botLabel.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botLabel.Location = new System.Drawing.Point(8, 8);
            this.botLabel.Name = "botLabel";
            this.botLabel.Size = new System.Drawing.Size(69, 18);
            this.botLabel.TabIndex = 4;
            this.botLabel.Text = "Status: ";
            // 
            // dgv
            // 
            this.dgv.AllowUserToAddRows = false;
            this.dgv.AllowUserToDeleteRows = false;
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(207, 543);
            this.dgv.Name = "dgv";
            this.dgv.ReadOnly = true;
            this.dgv.Size = new System.Drawing.Size(27, 16);
            this.dgv.TabIndex = 3;
            // 
            // tbLat
            // 
            this.tbLat.Location = new System.Drawing.Point(44, 53);
            this.tbLat.Name = "tbLat";
            this.tbLat.Size = new System.Drawing.Size(121, 20);
            this.tbLat.TabIndex = 4;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Location = new System.Drawing.Point(24, 297);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 5;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel1.Controls.Add(this.cbTeam);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.cbEmergency);
            this.panel1.Controls.Add(this.lbEmergency);
            this.panel1.Controls.Add(this.tbLong);
            this.panel1.Controls.Add(this.lbLong);
            this.panel1.Controls.Add(this.lbLat);
            this.panel1.Controls.Add(this.tbLat);
            this.panel1.Controls.Add(this.btnSubmit);
            this.panel1.Location = new System.Drawing.Point(12, 122);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(205, 357);
            this.panel1.TabIndex = 6;
            // 
            // cbTeam
            // 
            this.cbTeam.FormattingEnabled = true;
            this.cbTeam.Items.AddRange(new object[] {
            "Alpha",
            "Bravo",
            "Charlie"});
            this.cbTeam.Location = new System.Drawing.Point(44, 251);
            this.cbTeam.Name = "cbTeam";
            this.cbTeam.Size = new System.Drawing.Size(121, 21);
            this.cbTeam.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(19, 224);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 11;
            this.label1.Text = "Team:";
            // 
            // cbEmergency
            // 
            this.cbEmergency.FormattingEnabled = true;
            this.cbEmergency.Items.AddRange(new object[] {
            "Road Accidents",
            "Natural Disasterss",
            "Fire"});
            this.cbEmergency.Location = new System.Drawing.Point(44, 189);
            this.cbEmergency.Name = "cbEmergency";
            this.cbEmergency.Size = new System.Drawing.Size(121, 21);
            this.cbEmergency.TabIndex = 7;
            // 
            // lbEmergency
            // 
            this.lbEmergency.AutoSize = true;
            this.lbEmergency.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbEmergency.Location = new System.Drawing.Point(19, 162);
            this.lbEmergency.Name = "lbEmergency";
            this.lbEmergency.Size = new System.Drawing.Size(113, 24);
            this.lbEmergency.TabIndex = 9;
            this.lbEmergency.Text = "Emergency:";
            // 
            // tbLong
            // 
            this.tbLong.Location = new System.Drawing.Point(44, 113);
            this.tbLong.Name = "tbLong";
            this.tbLong.Size = new System.Drawing.Size(121, 20);
            this.tbLong.TabIndex = 8;
            // 
            // lbLong
            // 
            this.lbLong.AutoSize = true;
            this.lbLong.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLong.Location = new System.Drawing.Point(19, 86);
            this.lbLong.Name = "lbLong";
            this.lbLong.Size = new System.Drawing.Size(103, 24);
            this.lbLong.TabIndex = 7;
            this.lbLong.Text = "Longtitude:";
            // 
            // lbLat
            // 
            this.lbLat.AutoSize = true;
            this.lbLat.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbLat.Location = new System.Drawing.Point(19, 26);
            this.lbLat.Name = "lbLat";
            this.lbLat.Size = new System.Drawing.Size(80, 24);
            this.lbLat.TabIndex = 6;
            this.lbLat.Text = "Latitude:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Highlight;
            this.ClientSize = new System.Drawing.Size(1103, 601);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.botPanel);
            this.Controls.Add(this.topPanel);
            this.Controls.Add(this.gmap);
            this.Controls.Add(this.dgv);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.topPanel.ResumeLayout(false);
            this.topPanel.PerformLayout();
            this.botPanel.ResumeLayout(false);
            this.botPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GMap.NET.WindowsForms.GMapControl gmap;
        private System.Windows.Forms.Panel topPanel;
        private System.Windows.Forms.Label topLabel;
        private System.Windows.Forms.Panel botPanel;
        private System.Windows.Forms.Label botLabel;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.TextBox tbLat;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbTeam;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbEmergency;
        private System.Windows.Forms.Label lbEmergency;
        private System.Windows.Forms.TextBox tbLong;
        private System.Windows.Forms.Label lbLong;
        private System.Windows.Forms.Label lbLat;
    }
}

