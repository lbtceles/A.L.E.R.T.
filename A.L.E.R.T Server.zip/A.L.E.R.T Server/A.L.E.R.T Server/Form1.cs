﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GMap.NET.WindowsForms;
using GMap.NET.MapProviders;
using GMap.NET;
using GMap.NET.WindowsForms.Markers;
using System.Data.SqlClient;

namespace A.L.E.R.T_Server
{
    public partial class Form1 : Form
    {
        double lati;
        double longti;

        GMapOverlay overLay = new GMapOverlay();

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLExpress;Initial Catalog=A.L.E.R.T;Integrated Security=True");
        SqlDataAdapter sda;
        SqlCommand cmd;

        DataTable dt = new DataTable();

        int index;

        public void gmapRefresh()
        {
            foreach (DataGridViewRow row in dgv.Rows)
            {
                double rowLat = Convert.ToDouble(row.Cells[1].Value.ToString());
                double rowLong = Convert.ToDouble(row.Cells[2].Value.ToString());

                PointLatLng point = new PointLatLng(rowLat, rowLong);
                GMapMarker mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.red_dot);
                mapMarker.ToolTipText = index.ToString();
                index += 1;
                overLay.Markers.Add(mapMarker);

            }
            index = 1;
        }

        public Form1()
        {
            InitializeComponent();

            gmap.MapProvider = GMapProviders.GoogleMap; //setting of map provider
            gmap.Position = new PointLatLng(14.5823, 121.1260);

            gmap.MinZoom = 1;
            gmap.MaxZoom = 100;
            gmap.Zoom = 15;

            gmap.DragButton = MouseButtons.Left;
            gmap.AutoScroll = true;
            gmap.ShowCenter = false;

            gmap.Overlays.Add(overLay);
            // gmap.IgnoreMarkerOnMouseWheel = true;
        }



        private void Form1_Load(object sender, EventArgs e) // FORM LOAD
        {
            //CHECKING IF THE DATABASE CAN BE ACCESSED
            try
            {
                con.Open();
                botLabel.Text = botLabel.Text + " Connected!";
                con.Close();
            }
            catch(Exception ex)
            {
                botLabel.Text = botLabel.Text + " Not Connected!";
            }

            //LOADING THE MARKERS
            sda = new SqlDataAdapter("SELECT * FROM tblMarkers",con);
            sda.Fill(dt);
            dgv.DataSource = dt;

            foreach(DataGridViewRow row in dgv.Rows)
            {

                double rowLat = Convert.ToDouble(row.Cells[1].Value.ToString());
                double rowLong = Convert.ToDouble(row.Cells[2].Value.ToString());

                PointLatLng point = new PointLatLng(rowLat,rowLong);
                GMapMarker mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.red_dot);
                mapMarker.ToolTipText = index.ToString();
                index += 1;
                overLay.Markers.Add(mapMarker);

            }
            index = 1;

            

            gmap.OnMarkerClick += (marker, mouseArgs) =>
            {
                /*
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT Latitude FROM tblMarkers WHERE Marker_ID = '" + marker.ToolTipText + "'",con);
                MessageBox.Show(cmd.ExecuteScalar().ToString());
                con.Close();
            */
           };

        }


        private void gmap_DoubleClick(object sender, MouseEventArgs e) //DOUBLE CLICK TO ADD MARKER
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                this.lati = gmap.FromLocalToLatLng(e.X, e.Y).Lat;
                this.longti = gmap.FromLocalToLatLng(e.X, e.Y).Lng;
            }

            /* add markers */
            PointLatLng point = new PointLatLng(this.lati, this.longti);
            GMapMarker mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.red_big_stop);

            overLay.Markers.Add(mapMarker);



                
            /*
            PointLatLng loc = new PointLatLng(this.lati, this.longti);
            GMapMarker mapMarker = new GMarkerGoogle(loc, GMarkerGoogleType.red_big_stop);
            
            overLay.Markers.Add(mapMarker);
            */
        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (tbLat.Text == "" || tbLong.Text == "" || cbEmergency.Text == "" || cbTeam.Text == "")
            {
                MessageBox.Show("Please fill out all fields.");
            }
            else
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * FROM tblMarkers", con);
                dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 0)
                    cmd = new SqlCommand("INSERT INTO tblMarkers(Marker_ID,Latitude,Longtitude,Emergency,Team,Status) VALUES('1','" + tbLat.Text + "', '" + tbLong.Text + "', '" + cbEmergency.Text + "', '" + cbTeam.Text + "', 'Active')", con);
                else
                {
                    int count = dt.Rows.Count + 1;
                    cmd = new SqlCommand("INSERT INTO tblMarkers(Marker_ID,Latitude,Longtitude,Emergency,Team,Status) VALUES('"+ count +"','" + tbLat.Text + "', '" + tbLong.Text + "', '" + cbEmergency.Text + "', '" + cbTeam.Text + "','Active')", con);

                }

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

                gmapRefresh();
                MessageBox.Show("Marker Added!");

            }
        }

        private void gmap_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left)
            {
                SqlDataAdapter sda = new SqlDataAdapter("SELECT * from tblMarkers", con);
                dt = new DataTable();
                sda.Fill(dt);

                if (overLay.Markers.Count > dt.Rows.Count)
                    overLay.Markers.RemoveAt(overLay.Markers.Count - 1);

                tbLat.Text = gmap.FromLocalToLatLng(e.X, e.Y).Lat.ToString();
                tbLong.Text = gmap.FromLocalToLatLng(e.X, e.Y).Lng.ToString();

                PointLatLng point = new PointLatLng(Convert.ToDouble(tbLat.Text), Convert.ToDouble(tbLong.Text));
                GMapMarker mapMarker = new GMarkerGoogle(point, GMarkerGoogleType.red_dot);
                overLay.Markers.Add(mapMarker);


            }
        }
    }
}
